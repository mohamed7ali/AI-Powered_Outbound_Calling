# Arabic AI-Powered Outbound Follow-Up Calls

This repository implements a **multi-tenant Arabic customer follow-up platform**. The platform places an outbound call to a customer, asks whether the previously discussed issue was resolved, records the conversation outcome and duration, and ends the automated call. When the issue is unresolved or ambiguous, the system creates a post-call human-agent task; it does **not** transfer the live call. The human agent then uses the Arabic RAG assistant, grounded in the active organization’s private documents, to continue the case.

## Functional scope

| Capability | Implementation |
|---|---|
| Outbound follow-up calls | Vonage Voice API for live calls and a deterministic simulator for development |
| Arabic conversation | Vonage NCCO `talk` and `input` actions with Egyptian Arabic configuration, plus Arabic normalization and answer classification |
| Call persistence | `calls`, `call_turns`, and `call_events` store provider IDs, final text turns, raw provider events, status, outcome, and duration |
| Post-call routing | Resolved, human follow-up, no-answer, busy, failed, and bounded retry states |
| First-call-resolution reporting | Organization-scoped aggregation of outcomes, answer rate, FCR rate, escalation count, and average duration |
| Agent assistant | Hybrid pgvector plus PostgreSQL full-text retrieval with organization-scoped citations and conversation persistence |
| Documents | Private Supabase Storage upload for PDF, DOCX, TXT, MD, CSV, and JSON; extraction, chunking, embedding, and ingestion |
| Tenant hierarchy | Platform administrator → organization administrator → agent, with JWT membership verification and PostgreSQL RLS |
| User interface | Gradio tabs for login, campaigns, agent desk, documents, reports, and administration |
| Runtime | FastAPI API, Gradio UI, scheduler worker, Docker Compose |

## Architecture and data isolation

The database is Supabase PostgreSQL with `pgvector`. Every business table carries `organization_id`, and organization membership is represented by `organization_memberships`. User-facing transactions set PostgreSQL tenant context and run under the authenticated role. Vonage callbacks and the scheduler use narrowly scoped trusted transactions because they are server-originated events or worker operations; they correlate calls using persisted provider IDs and internal metadata rather than trusting a client-supplied organization as the source of truth.

> A customer, case, call, document, chunk, conversation, escalation, and report can only be queried through the organization context resolved from the authenticated user’s membership. A platform administrator may select an active organization explicitly; an organization administrator or agent must be an active member of that organization.

The automated call has no live-transfer branch. A resolved answer writes `ANSWERED_RESOLVED`; an unresolved or ambiguous answer writes `ESCALATED` and creates an escalation record, then the Vonage assistant ends the call. The human workflow is deliberately separate from the telephony callback so an agent can review the call and use the organization-specific knowledge base safely.

## Repository layout

```text
docs/                                   architecture, database, Vonage, audit, runbooks
supabase/migrations/                    schema, RLS, vector search, storage policies
supabase/seed.sql                       development seed data
scripts/run_scheduler.py                persistent follow-up worker entrypoint
src/outbound_ai/api/                    FastAPI app, JWT auth, Vonage, campaign, documents, reports, admin
src/outbound_ai/db/                     connection and tenant-filtered repositories
src/outbound_ai/rag/                    Arabic chunking, embeddings, loaders, storage, ingestion
src/outbound_ai/reports/                FCR service and reporting facade
src/outbound_ai/telephony/              Vonage adapter, simulator, scheduler, routing, provider port
src/outbound_ai/ui/app.py               Gradio operations console
tests/unit/                             unit and contract tests
Dockerfile                              production application image
docker-compose.yml                      API, UI, and scheduler services
```

## Local setup

Use Python 3.11 or 3.12. Create a virtual environment, install the package, and copy the environment template. The test suite does not place real calls and can run with deterministic embeddings and the simulated telephony provider.

```bash
python3 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e ".[dev]"
cp .env.example .env

PYTHONPATH=src python -m pytest -q
```

Set `RAG_EMBEDDING_PROVIDER=deterministic` for an offline demonstration. For production retrieval, set it to `openai`, configure `OPENAI_API_KEY`, and ensure the embedding dimension remains `3072`, matching the database vector column. Set `TELEPHONY_PROVIDER=simulated` during development. Use `vonage` only after configuring a Voice-enabled Vonage Application, private key, public key, virtual number, and public HTTPS callback URL.

## Supabase setup

Create a Supabase project, enable the required extensions through the supplied migrations, and apply the migrations under `supabase/migrations/`. The schema creates organizations, profiles, platform administrators, memberships, customers, cases, follow-up tasks, calls, call events, call turns, escalations, FCR reports, knowledge documents, knowledge chunks, conversations, messages, audit events, RLS policies, the private document bucket, and the hybrid search function.

Configure the direct PostgreSQL connection in `DATABASE_URL`. Configure `SUPABASE_URL`, `SUPABASE_ANON_KEY`, and `SUPABASE_SERVICE_ROLE_KEY`. For JWT verification, prefer Supabase JWKS by leaving `SUPABASE_JWT_SECRET` blank; for legacy HS256 projects, set `SUPABASE_JWT_SECRET`. Never expose the service-role key to the browser or Gradio client.

The first platform administrator must be inserted into `platform_admins` through a controlled SQL migration or protected bootstrap procedure. Organization users should be invited through the authenticated administration endpoint, which calls Supabase Auth with the service-role key on the server and then creates the organization membership.

## Vonage configuration

Create a Vonage Voice Application and configure its answer/event Server URL as:

```text
https://YOUR-PUBLIC-API-HOST/vonage/answer
https://YOUR-PUBLIC-API-HOST/vonage/event
```

Keep the private key outside Git and configure `.env`:

```dotenv
TELEPHONY_PROVIDER=vonage
VONAGE_APPLICATION_ID=your-application-id
VONAGE_PRIVATE_KEY_PATH=private.key
VONAGE_PUBLIC_KEY_PATH=public.key
VONAGE_FROM_NUMBER=your-vonage-virtual-number
VONAGE_VERIFY_WEBHOOKS=true
PUBLIC_WEBHOOK_BASE_URL=https://YOUR-PUBLIC-API-HOST
```

The selected case’s `customers.phone_e164` value is the destination number. The detailed setup procedure is in [`docs/vonage_integration.md`](docs/vonage_integration.md).

## Run the services directly

Start the API and UI in separate terminals, then start the scheduler as a separate long-running process. The scheduler claims due rows with `FOR UPDATE SKIP LOCKED`, originates calls through the configured Vonage or simulated adapter, and applies exponential retry backoff without duplicating work across workers.

```bash
PYTHONPATH=src uvicorn outbound_ai.api.app:app --host 0.0.0.0 --port 8000
PYTHONPATH=src python -m outbound_ai.ui.app
PYTHONPATH=src python scripts/run_scheduler.py
```

The API health endpoint is `GET /health`. The main authenticated endpoints are `POST /agent/query`, `GET/POST /campaign/*`, `POST /reports/fcr`, `GET/POST /documents/*`, and `POST/GET /admin/*`. User-facing requests require `Authorization: Bearer <Supabase access token>` and `X-Organization-Id`. Vonage callbacks are authenticated according to the configured Vonage webhook verification mode.

## Run with Docker Compose

Copy `.env.example` to `.env`, fill in the secrets, and run the three services. The UI uses `API_BASE_URL=http://api:8000` inside the Compose network; browsers access it through the published port.

```bash
docker compose up --build -d
docker compose logs -f api scheduler ui
```

The default ports are `8000` for FastAPI and `7860` for Gradio. Put a TLS reverse proxy in front of both services for production, restrict access to the Gradio console, rotate service credentials, and use a managed process supervisor or container orchestrator for restart and health monitoring.

## Production checklist

Before handling real customers, apply and review all Supabase migrations, seed a platform administrator through a controlled procedure, configure JWT verification, confirm organization membership and RLS tests, configure private Storage policies, configure a Vonage Voice Application and virtual number, expose the Vonage callbacks behind public HTTPS, and validate Arabic speech quality on representative calls. Confirm that logs redact phone numbers, raw speech, authorization headers, and service credentials. Start the scheduler only once the database and telephony provider are reachable.

The repository contains a passing unit and contract suite covering database/RLS contracts, Vonage adapter behavior, Arabic post-call routing, scheduler lifecycle, escalation behavior, RAG behavior, and FCR metric edge cases. External prerequisites remain external by design: the deployed Supabase project, Gemini/OpenAI-compatible credentials, Vonage application and number, TLS/public webhook URL, and the first platform-admin bootstrap must be supplied by the operator.

## Key documentation

| Document | Purpose |
|---|---|
| [`docs/00_use_case.md`](docs/00_use_case.md) | Requirements baseline and agreed post-call behavior |
| [`docs/05_voice_design.md`](docs/05_voice_design.md) | Vonage voice, Arabic TTS/STT, transcript, and recording boundaries |
| [`docs/06_database.md`](docs/06_database.md) | PostgreSQL, Supabase, RLS, Storage, and pgvector setup |
| [`docs/vonage_integration.md`](docs/vonage_integration.md) | Vonage Application, webhook, and live-call setup |
| [`docs/08_completeness_audit.md`](docs/08_completeness_audit.md) | Completion audit and operational boundaries |
| [`docs/09_codespaces_deployment_runbook.md`](docs/09_codespaces_deployment_runbook.md) | Codespaces deployment and demo procedure |
